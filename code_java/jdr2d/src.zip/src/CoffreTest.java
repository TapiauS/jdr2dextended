import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CoffreTest {

    @Test
    void getContenu() {
    }

    @Test
    void add() {
    }

    @Test
    void remove() {
    }

    @Test
    void testRemove() {
    }
}