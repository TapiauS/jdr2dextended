public class Porte extends Point{
    private Porte portelie;

    //getters

    public Porte getPortelie() {
        return portelie;
    }

    //setters


    public Porte setPortelie(Porte portelie) {
        this.portelie = portelie;
        return this;
    }

}
